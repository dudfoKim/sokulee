"""
Constants for the PyOWM library
"""

PYOWM_VERSION = '2.3.0'
LATEST_OWM_API_VERSION = '2.5'
