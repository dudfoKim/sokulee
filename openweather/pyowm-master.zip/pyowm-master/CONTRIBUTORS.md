Thanks to the contributors
==========================

Contributors will be shown in alphabetical order

Code
----
  * [liato] (https://github.com/liato)
  * [Noid] (https://github.com/n0id)
  * [dphildebrandt] (https://github.com/dphildebrandt)

Testing
-------
  * [Samuel Yap] (https://github.com/samuelyap)

Wiki
----
  * [richarddunks] (https://github.com/richarddunks)
  * [solumos] (https://github.com/solumos)
